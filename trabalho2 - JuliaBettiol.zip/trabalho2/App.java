import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;


public class App {

	public static void main(String[]  args) {
		
		 String[] files = new String[]{ "texto01.txt","texto02.txt", "texto03.txt",
				 "texto04.txt", "texto05.txt","texto06.txt", "texto07.txt",
				 "texto08.txt", "texto09.txt","texto10.txt" };

		 TextAnalysis dicionario = new TextAnalysis(files);

		 Scanner sc = new Scanner(System.in);

		 while (true) {
			System.out.println("Escolha uma das opções: ");
			System.out.println("1 - Listar aquivos que contém a palavra que deseja procurar");
			System.out.println("2 - Listar arquivos que contém duas ou mais palavras que deseja procurar ");
			System.out.println("3 - Listar palavras que aparecem no arquivo com frequencia");
			System.out.println("4 - Listar palavras que aparecem em ambos arquivos");
			System.out.println("5 - Sair");

			int escolha = sc.nextInt();
			sc.nextLine();

			switch (escolha) {
			
				case 1:
					System.out.println("Palavra que deseja buscar: ");
					String palavra = sc.nextLine();
					TextAnalysis.listarArquivos(palavra);
					break;

				case 2: 
					System.out.println("Palavras que deseja buscar: ");
					String[] palavras = sc.nextLine().split("\\s+");
					TextAnalysis.listarArquivos(palavras);
					break;

				case 3:
					System.out.println("Nome do arquivo: ");
					String arquivo = sc.nextLine();
					TextAnalysis.listarPalavras(arquivo);
					break;

				case 4:
					System.out.println("Nome do primeiro arquivo: ");
					String arquivo1 = sc.nextLine();
					System.out.println("Nome segundo arquivo:");
					String arquivo2 = sc.nextLine();
					TextAnalysis.listarPalavrasComuns(arquivo1, arquivo2);
					break;

				case 5:
					sc.close();
					System.exit(0);
					
				default:
				System.out.println("Opção invalida");

			}
		} 
	}
 }