import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class TextAnalysis { 

	//rastrear palavras e arquivos
	private static Map<String, Set<String>> palavraMap;
	private static Map<String, Map<String, Integer>> contaPalavraMap;

	public TextAnalysis(String[] files) { //construtor
		palavraMap = new HashMap<>(0, 0);
		contaPalavraMap = new HashMap<>(0);

		for (String fname : files ) { 
			this.carregaDados(fname);
		}
	}
	
	public static void listarArquivos(String palavra) { //palavra entrada e ve se existe no map 
		if (palavraMap.containsKey(palavra)) {
			Set<String> files = palavraMap.get(palavra);
			System.out.println("Palavra " + palavra + "aparece nos arquivos:");
			for (String file : files) {
				System.out.println(file);
			}
		} else {
			System.out.println("Palavra " + palavra + "nao encontrada");
		}
	}
	
	public static void listarArquivos(String[] palavras) { //recebe array palavras entradas
		Set<String> arquivoComum = null;
		for (String palavra : palavras) {
			if (palavraMap.containsKey(palavra)) { //verifica se existe no map
				if (arquivoComum == null) {
					arquivoComum = new HashSet<>(0, 0); //se existe cria conjunto
				} else {
					arquivoComum.retainAll(palavraMap.get(palavra)); //manter aquivos comuns
				} 
			} else {
					System.out.println("Palavra " + palavra + "nao encontrada");
					return;
				}
			}
			if (arquivoComum != null && !arquivoComum.isEmpty()) {
				System.out.println("As palavras comuns aparecem nos arquivos: ");
				for (String file : arquivoComum) {
					System.out.println(file);
				}
			} else {
				System.out.println("Estas palavras nao contem nos arquivos");
			}
		}
	
	public static void listarPalavras(String fileName) { //mapeia arquivos para a contagem de palavras
		if (contaPalavraMap.containsKey(fileName)) {
			Map<String, Integer> contarPalavra = contaPalavraMap.get(fileName);
			System.out.println("Palavras no arquivo: " + fileName);
			for (Map.Entry<String, Integer> entry : contarPalavra.entrySet()) {
				System.out.println(entry.getKey() + " " + entry.getValue() + "vezes");
			}		
		} else {
			System.out.println("Nao contem a palavra");
		}
	}
	
	public static void listarPalavrasComuns(String f1, String f2) { //verifica se ambos arquivos existem no map 
		if (contaPalavraMap. containsKey(f1) && contaPalavraMap.containsKey(f2)) {
			Map<String, Integer> palavrasArquivo1 = contaPalavraMap.get(f1);
			Map<String, Integer> palavrasArquivo2 = contaPalavraMap.get(f2);
			
			System.out.println("Palavras comuns nos arquivos " + f1 + " " + f2);
			for (String palavra : palavrasArquivo1.keySet()) {
				if (palavrasArquivo2.containsKey(palavra)) {
					System.out.println(palavra);
				}
			}	
		} else {
			System.out.println("Erro");
		}
	}

	private void carregaDados(String fileName) { //processar um arquivo
		Path path1 = Paths.get(fileName);
		System.out.println("\nArquivo: "+fileName);

		try (BufferedReader reader = Files.newBufferedReader(path1, Charset.forName("utf8"))) {
			String line;
			while ((line = reader.readLine()) != null) {
				line = line.toLowerCase().replaceAll("[^a-zA-Záéíóúçãõà-]"," ");
				String[] palavras = line.split("\\s+");
				
				System.out.println(line);

				for(String palavra : palavras) {
					if (!palavra.isEmpty()) {

						palavraMap.computeIfAbsent(palavra, k -> new HashSet<>(0, 0)).add(fileName);

						contaPalavraMap
							.computeIfAbsent(fileName, k -> new HashMap<>(0, 0))
							.merge(palavra, 1, Integer::sum);
					}
				}

			}

		} catch (IOException e) {
			System.out.println("Erro na leitura: "+e.getMessage());
		}
	}
}

